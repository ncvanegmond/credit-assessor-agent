# CreditMate Sandbox

A prototype implementation of an agentic AI system designed to automate parts of the credit assessment process for bridge loans at an Australian non-bank lender.

## Features

- Modular Python components
- Simulated document extraction
- Credit policy enforcement
- Decision recommendations
- Reviewer-friendly summary output

## Folder Structure

```
.
├── ocr_parser.py
├── income_calculator.py
├── risk_rules.py
├── recommendation_engine.py
├── review_ui.py
├── main.py
├── requirements.txt
└── README.md
```

## Getting Started

### 1. Clone the repository or unzip locally
```bash
git clone https://github.com/YOUR_ORG/creditmate-sandbox.git
cd creditmate-sandbox
```

### 2. Set up a virtual environment
```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the simulation
```bash
python main.py
```

## Notes

- This is a mock implementation. Replace stubbed functions with integrations (e.g. OCR APIs, GPT-4o).
- Modify `main.py` to test different scenarios and override cases.