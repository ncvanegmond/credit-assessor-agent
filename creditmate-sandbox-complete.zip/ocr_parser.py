# ocr_parser.py
# Parses structured fields from OCR output (stubbed for demo)

def extract_fields(document_text):
    # Simulate extracted data
    return {
        'full_name': 'John Smith',
        'dob': '1985-06-21',
        'declared_income_monthly': 8500,
        'employment_type': 'PAYG'
    }