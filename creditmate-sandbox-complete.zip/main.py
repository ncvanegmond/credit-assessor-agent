from ocr_parser import extract_fields
from income_calculator import calculate_net_income
from risk_rules import apply_rules
from recommendation_engine import generate_recommendation
from review_ui import display_summary

# Stubbed input
document_text = """Payslip for John Smith: Monthly Income $8,500"""
bank_transactions = [
    {'type': 'income', 'amount': 8500},
    {'type': 'expense', 'amount': 3000},
    {'type': 'expense', 'amount': 1500}
]
lvr = 63  # Example input
income_stability_months = 4

# Pipeline
applicant_data = extract_fields(document_text)
net_income = calculate_net_income(bank_transactions)
issues = apply_rules(lvr, income_stability_months)
recommendation = generate_recommendation(applicant_data, lvr, net_income, issues)

# Output
display_summary(recommendation)