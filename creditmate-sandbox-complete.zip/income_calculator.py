# income_calculator.py
# Calculates net disposable income

def calculate_net_income(bank_transactions):
    income = sum(txn['amount'] for txn in bank_transactions if txn['type'] == 'income')
    expenses = sum(txn['amount'] for txn in bank_transactions if txn['type'] == 'expense')
    return income - expenses