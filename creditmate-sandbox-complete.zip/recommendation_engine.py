# recommendation_engine.py
# Compiles decision recommendation

def generate_recommendation(applicant_data, lvr, net_income, issues):
    if issues:
        decision = 'Refer'
    else:
        decision = 'Approve'

    return {
        'applicant': applicant_data['full_name'],
        'decision': decision,
        'summary': {
            'LVR': f'{lvr}%',
            'Net Income': f'AUD {net_income:.2f}',
            'Issues': issues
        }
    }