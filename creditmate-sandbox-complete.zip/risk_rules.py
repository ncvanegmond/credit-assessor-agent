# risk_rules.py
# Applies basic credit policy checks

def apply_rules(lvr, income_stability_months):
    issues = []
    if lvr > 65:
        issues.append('LVR exceeds 65% policy limit.')
    if income_stability_months < 3:
        issues.append('Income not stable for 3+ months.')
    return issues