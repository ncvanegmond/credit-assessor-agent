# review_ui.py
# Outputs summary for reviewer

def display_summary(recommendation):
    print(f"\nApplicant: {recommendation['applicant']}")
    print(f"Decision: {recommendation['decision']}")
    print("Summary:")
    for k, v in recommendation['summary'].items():
        print(f" - {k}: {v}")